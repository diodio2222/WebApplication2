﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SuperHeroController : ControllerBase
    {
        [HttpGet]
        public string aaaa() {
            return "dsfdsfds2";
        }
        [HttpGet]
        [Route("api/[controller]/a")]
        public string aaafa()
        {
            return "dsfdsfds2";
        }
    }
}
 